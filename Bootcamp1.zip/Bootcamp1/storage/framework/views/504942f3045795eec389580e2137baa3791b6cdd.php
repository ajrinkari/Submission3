<?php echo e($pageTitle); ?> 
<br>
<?php echo e($content); ?><?php /**PATH C:\xampp\htdocs\Bootcamp1\resources\views/about.blade.php ENDPATH**/ ?>